<?php
//this file is required. If we don't have it, there are warnings in the log
//we are incorrectly displaying header in other template files like base.php via roots_template_path();
//ths is here to please WordPress and Elementor in full width mode